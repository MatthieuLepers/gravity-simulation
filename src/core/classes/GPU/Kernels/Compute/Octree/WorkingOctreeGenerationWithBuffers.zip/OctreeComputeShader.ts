import { ComputeShader, type IDebugBufferOptions } from '@/core/classes/Shaders/Compute';
import OctreeComputeShaderCode from '@/core/classes/Shaders/Compute/OctreeComputeShader.wgsl?raw';
import type { IGravityComputeShaderBuffers } from '@/core/classes/Shaders/Compute/GravityComputeShader';

export const MAX_PARTICLES_PER_NODE = 2500;

export const OCTREE_NODE_STRIDE = 20;

export const getMaxSubdivision = (particleCount: number) => Math.ceil(particleCount / MAX_PARTICLES_PER_NODE);

export const getMaxNodes = (particleCount: number) => ((8 ** (getMaxSubdivision(particleCount) + 1)) - 1) / 7;

export const formatBuffer = (arrayBuffer: ArrayBuffer): Array<number> => {
  const nodeCount = arrayBuffer.byteLength / (OCTREE_NODE_STRIDE * 4);
  const view = new DataView(arrayBuffer);

  return [...Array(nodeCount).keys()].reduce((acc, i) => {
    const offset = i * OCTREE_NODE_STRIDE * 4;

    return [
      ...acc,
      // minCorner
      view.getFloat32(offset, true),
      view.getFloat32(offset + 4, true),
      view.getFloat32(offset + 8, true),
      view.getFloat32(offset + 12, true),
      // maxCorner
      view.getFloat32(offset + 16, true),
      view.getFloat32(offset + 20, true),
      view.getFloat32(offset + 24, true),
      view.getFloat32(offset + 28, true),
      // childIndices
      view.getInt32(offset + 32, true),
      view.getInt32(offset + 36, true),
      view.getInt32(offset + 40, true),
      view.getInt32(offset + 44, true),
      view.getInt32(offset + 48, true),
      view.getInt32(offset + 52, true),
      view.getInt32(offset + 56, true),
      view.getInt32(offset + 60, true),
      // particleCount
      view.getUint32(offset + 64, true),
      // startIndex
      view.getUint32(offset + 68, true),
      // padding
      view.getFloat32(offset + 72, true),
      view.getFloat32(offset + 76, true),
    ];
  }, [] as Array<number>);
};

export const debugConfigs = (shader: ComputeShader<IOctreeComputeShaderBuffers>): Record<string, IDebugBufferOptions> => ({
  octreeNodes: {
    buffer: shader.resources.octreeNodes,
    formatBuffer,
    entityName: 'OctreeNode',
    entityStride: OCTREE_NODE_STRIDE,
  },
  freeNodeIndices: {
    buffer: shader.resources.freeNodeIndices,
    formatBuffer: (arrayBuffer) => Array.from(new Int32Array(arrayBuffer)),
    entityName: 'Free node indices',
    entityStride: getMaxNodes(shader.particleCount),
    logCount: 1,
  },
  freeNodeCounter: {
    buffer: shader.resources.freeNodeCounter,
    formatBuffer: (arrayBuffer) => Array.from(new Int32Array(arrayBuffer)),
    entityName: 'Free node counter',
    entityStride: 1,
    logCount: 1,
  },
  // debugCounter: {
  //   buffer: shader.buffers.debugCounter,
  //   formatBuffer: (arrayBuffer) => Array.from(new Int32Array(arrayBuffer)),
  //   entityName: 'Debug counter',
  //   entityStride: 10000,
  //   logCount: 1,
  // },
});

export interface IOctreeComputeShaderBuffers extends Record<string, GPUBuffer> {
  octreeNodes: GPUBuffer;
  freeNodeIndices: GPUBuffer;
  freeNodeCounter: GPUBuffer;
  // debugCounter: GPUBuffer;
}

export const MakeInitOctreeComputeShader = (
  device: GPUDevice,
  gravityComputeShader: ComputeShader<IGravityComputeShaderBuffers>,
) => {
  const MAX_NODES = getMaxNodes(gravityComputeShader.particleCount);
  const shader = new ComputeShader<IOctreeComputeShaderBuffers>(device, OctreeComputeShaderCode, 'cs_init_octree', gravityComputeShader.particleCount);

  shader.initBuffer('octreeNodes', {
    size: MAX_NODES * OCTREE_NODE_STRIDE * 4,
    usage: GPUBufferUsage.VERTEX | GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
  });
  shader.initBuffer('freeNodeIndices', {
    size: MAX_NODES * 4,
    usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
  });
  shader.initBuffer('freeNodeCounter', {
    size: 4,
    usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
  });
  // shader.initBuffer('debugCounter', {
  //   size: 40000,
  //   usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
  // });

  shader
    .setBinding(0, { buffer: gravityComputeShader.resources.particles })
    .setBinding(1, { buffer: shader.resources.octreeNodes })
    .setBinding(2, { buffer: shader.resources.freeNodeIndices })
    .setBinding(3, { buffer: shader.resources.freeNodeCounter })
    .initBindGroup()
  ;

  return shader;
};

export const MakeInsertParticlesComputeShader = (
  device: GPUDevice,
  particleCount: number,
  initOctreeComputeShader: ComputeShader<IOctreeComputeShaderBuffers>,
) => {
  const shader = new ComputeShader<IOctreeComputeShaderBuffers>(device, OctreeComputeShaderCode, 'cs_insert_particles', particleCount);

  shader.resources = initOctreeComputeShader.resources;
  shader.bindings = initOctreeComputeShader.bindings;
  // shader.setBinding(4, shader.buffers.debugCounter);
  shader.initBindGroup();

  return shader;
};
